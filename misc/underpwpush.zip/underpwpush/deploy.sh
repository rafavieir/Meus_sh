#!/bin/bash

sudo docker run -e PWP_PRECOMPILE=true \
    --mount type=bind,source=/home/rafael.andrade/.dev/underpwpush/modify/settings.yml,target=/opt/PasswordPusher/config/settings.yml \
    -p 5100:5100 pglombardo/pwpush-ephemeral:release

