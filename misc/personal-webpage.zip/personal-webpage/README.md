# Personal Webpage

A Pen created on CodePen.io. Original URL: [https://codepen.io/euforo/pen/XWvXVQV](https://codepen.io/euforo/pen/XWvXVQV).

A single page scrolling portfolio site I was working on using fullpage.js, wow.js and animate.css.