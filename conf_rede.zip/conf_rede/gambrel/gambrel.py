#Importanto as bibliotecas necessárias 
import os
import subprocess

print(f"Gambreeeel")