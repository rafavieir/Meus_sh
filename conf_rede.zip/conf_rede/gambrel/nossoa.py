import curses
import curses.textpad

def obter_dados(stdscr):
    stdscr.clear()
    stdscr.addstr(0, 0, "Configuração de Rede", curses.A_BOLD)  # Título da janela

    # Definindo as legendas e os campos de texto
    legendas_campos = [
        ("Nome da primeira interface: ", ""),
        ("Nome da segunda interface: ", ""),
        ("Número VLAN WAN: ", ""),
        ("IP WAN: ", ""),
        ("Máscara WAN: ", ""),
        ("GW WAN: ", ""),
        ("Número VLAN LAN: ", ""),
        ("IP LAN: ", ""),
        ("Máscara LAN: ", ""),
        ("GW LAN: ", ""),
        ("Contrato: ", "")
    ]

    # Inicializando uma lista para armazenar os dados inseridos
    dados = []

    # Criando e exibindo os campos de texto e legendas
    for i, (legenda, valor_inicial) in enumerate(legendas_campos):
        stdscr.addstr(2 + i, 2, legenda)
        campo_texto_win = curses.newwin(1, 30, 2 + i, 30)
        campo_texto_tb = curses.textpad.Textbox(campo_texto_win)
        campo_texto_tb.edit()
        campo_texto = campo_texto_tb.gather().strip()
        dados.append((legenda, campo_texto if campo_texto else valor_inicial))

    return dados

def main(stdscr):
    curses.curs_set(1)
    curses.use_default_colors()
    curses.init_pair(1, curses.COLOR_GREEN, -1)  # Definindo uma cor verde

    dados = obter_dados(stdscr)

    stdscr.clear()
    stdscr.addstr(0, 0, "Dados de rede recebidos com sucesso!", curses.color_pair(1))

    # Exibindo os dados recebidos
    for i, (legenda, valor) in enumerate(dados):
        stdscr.addstr(2 + i, 0, f"{legenda}{valor}", curses.A_BOLD)

    stdscr.addstr(3 + len(dados), 0, "Pressione qualquer tecla para sair.")

    stdscr.getch()

curses.wrapper(main)
