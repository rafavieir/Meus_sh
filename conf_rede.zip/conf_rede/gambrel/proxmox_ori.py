#Importanto as bibliotecas necessárias 
import os
import subprocess

#Solicitando as informações para serem usadas nas configurações
interface1 = input("Digite o nome da primeira interface: ")
interface2 = input("Digite o nome da segunda interface: ")
vlan_wan = input("Digite o número vlan WAN: ")
ip_wan = input("Qual é o ip WAN (Ex: 189.113.7.4): ")
mask_wan = input("Qual é a máscara WAN (Ex: 29): ")
gw_wan = input("Qual é o gw WAN (Ex: 189.113.7.1): ")
vlan_lan = input("Digite o número vlan LAN: ")
ip_lan = input("Qual é o ip LAN (Ex: 10.32.0.2): ")
mask_lan = input("Qual é a máscara LAN (Ex: 28): ")
gw_lan = input("Qual é o gw LAN (Ex: 10.32.0.1): ")
contrato = input("Qual é o contrato: ")


#Início das configurações

# Configuração inicial da rede
caminho_arquivo_rede = "/etc/network/interfaces"

conteudo_rede = f"""auto lo
iface lo inet loopback

iface {interface1} inet manual

iface {interface2} inet manual

auto bond0
iface bond0 inet manual
bond-slaves {interface1} {interface2}
bond-mode 802.3ad
bond-miimon 100
bond-lacp-rate 1

auto vmbr0
iface vmbr0 inet manual
bridge_ports bond0
bridge_stp off
bridge_fd 0

auto vmbr0v{vlan_wan}
iface vmbr0v{vlan_wan} inet static
bridge_ports bond0.{vlan_wan}
address {ip_wan}/{mask_wan}
gateway {gw_wan}
bridge_stp off
bridge_fd 0

auto vmbr0v{vlan_lan}
iface vmbr0v{vlan_lan} inet manual
bridge_ports bond0.{vlan_lan}
#address {ip_lan}/{mask_lan}
#gateway {gw_lan}
bridge_stp off
bridge_fd 0
"""


# Tente abrir o arquivo em modo de escrita e escrever o conteúdo  do arquivo de rede
try:
    with open(caminho_arquivo_rede, 'w') as arquivo:
        arquivo.write(conteudo_rede)
    print(f"Arquivo '{caminho_arquivo_rede}' criado com sucesso. Ao final da configuração, inverter a rede WAN pela rede LAN")
except IOError as e:
    print(f"Erro ao criar o arquivo '{caminho_arquivo_rede}': {e}")

# Configuração inicial do NTP
# Caminho completo do arquivo NTP
caminho_arquivo_NTP = "/etc/chrony/chrony.conf"

conteudo_NTP = """# Welcome to the chrony configuration file. See chrony.conf(5) for more
# information about usable directives.

# Include configuration files found in /etc/chrony/conf.d.
confdir /etc/chrony/conf.d

# Use Debian vendor zone.
pool ntp.underserver.com.br iburst
pool ntp2.underserver.com.br iburst
pool ntp3.underserver.com.br iburst
pool ntp4.underserver.com.br iburst
pool 10.64.2.6 iburst
pool 10.64.2.12 iburst
pool 10.64.2.13 iburst
pool 10.64.2.14 iburst

# Use time sources from DHCP.
sourcedir /run/chrony-dhcp

# Use NTP sources found in /etc/chrony/sources.d.
sourcedir /etc/chrony/sources.d

# This directive specify the location of the file containing ID/key pairs for
# NTP authentication.
keyfile /etc/chrony/chrony.keys

# This directive specify the file into which chronyd will store the rate
# information.
driftfile /var/lib/chrony/chrony.drift

# Save NTS keys and cookies.
ntsdumpdir /var/lib/chrony

# Uncomment the following line to turn logging on.
#log tracking measurements statistics

# Log files location.
logdir /var/log/chrony

# Stop bad estimates upsetting machine clock.
maxupdateskew 100.0

# This directive enables kernel synchronisation (every 11 minutes) of the
# real-time clock. Note that it can't be used along with the 'rtcfile' directive.
rtcsync

# Step the system clock instead of slewing it if the adjustment is larger than
# one second, but only in the first three clock updates.
makestep 1 3

# Get TAI-UTC offset and leap seconds from the system tz database.
# This directive must be commented out when using time sources serving
# leap-smeared time.
leapsectz right/UTC
"""

# Tente abrir o arquivo em modo de escrita e escrever o conteúdo NTP
try:
    with open(caminho_arquivo_NTP, 'w') as arquivo:
        arquivo.write(conteudo_NTP)
    print(f"Arquivo '{caminho_arquivo_NTP}' criado com sucesso.")
except IOError as e:
    print(f"Erro ao criar o arquivo '{caminho_arquivo_NTP}': {e}")

# Configuração do hosts
# Caminho completo do arquivo hosts
caminho_arquivo_hosts = "/etc/hosts"

conteudo_hosts = f"""127.0.0.1 localhost.localdomain localhost
{ip_lan} {contrato}.gravserver.com {contrato}

# The following lines are desirable for IPv6 capable hosts

::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
ff02::3 ip6-allhosts
"""

# Tente abrir o arquivo em modo de escrita e escrever o conteúdo NTP
try:
    with open(caminho_arquivo_hosts, 'w') as arquivo:
        arquivo.write(conteudo_hosts)
    print(f"Arquivo '{caminho_arquivo_hosts}' criado com sucesso.")
except IOError as e:
    print(f"Erro ao criar o arquivo '{caminho_arquivo_hosts}': {e}")


# Executar os comandos gerais (restart na rede, ajuste no resolv.conf, ajuste nos repositórios, update e upgrade, ajuste NTP, ajuste hostname e teste de velocidade)
#Instalação do Zabbix


commands1 = [
        "timedatectl set-timezone America/Sao_Paulo",
        "service networking restart",
        "echo nameserver 189.113.7.4 > /etc/resolv.conf",
        "echo nameserver 8.8.8.8 >> /etc/resolv.conf",
        "rm -rf /etc/apt/sources.list.d/*",
        "apt update -y",
        "apt upgrade -y",
        "apt install openvswitch-switch -y",
        "systemctl restart chronyd",
        f"echo {contrato} > /etc/hostname",
        "wget https://github.com/ddo/fast/releases/download/v0.0.4/fast_linux_amd64 -O fast && chmod +x fast && for i in `seq 1 3` ; do ./fast ; done",
        "apt install zabbix-agent -y",
        "apt install smartmontools -y",
        "chmod u+s /usr/sbin/smartctl",
        "ln /usr/sbin/smartctl /usr/bin/smartctl",
        "echo zabbix ALL=NOPASSWD: /usr/sbin/smartctl > /etc/sudoers.d/smartctl",
]
for command in commands1:
    try:
        subprocess.run(command, shell=True, check=True)
        print(f"Comando '{command}' executado com sucesso.")
    except subprocess.CalledProcessError as e:
        print(f"Erro ao executar o comando '{command}': {e}")

# Caminho completo do arquivo smartctl.conf
caminho_arquivo_smartctl = "/etc/zabbix/zabbix_agentd.conf.d/smartctl.conf"

conteudo_smartctl = """UserParameter=total.written.disk0,smartctl -d cciss,0 -A /dev/sda | grep 241 | awk '{print $10}'
UserParameter=total.written.disk1,smartctl -d cciss,1 -A /dev/sda | grep 241 | awk '{print $10}'
UserParameter=power.on.disk0,smartctl -d cciss,0 -A /dev/sda | grep Power_On_Hours | awk '{print $10}'
UserParameter=power.on.disk1,smartctl -d cciss,1 -A /dev/sda | grep Power_On_Hours | awk '{print $10}'
UserParameter=health.disk0,smartctl -d cciss,0 -A /dev/sda | grep 231 | awk '{print $10}'
UserParameter=health.disk1,smartctl -d cciss,1 -A /dev/sda | grep 231 | awk '{print $10}'
"""

# Tente abrir o arquivo em modo de escrita e escrever o conteúdo smartctl
try:
    with open(caminho_arquivo_smartctl, 'w') as arquivo:
        arquivo.write(conteudo_smartctl)
    print(f"Arquivo '{caminho_arquivo_smartctl}' criado com sucesso.")
except IOError as e:
    print(f"Erro ao criar o arquivo '{caminho_arquivo_smartctl}': {e}")

# Substituir linhas no arquivo zabbix_agentd.conf
zabbix_conf_path = "/etc/zabbix/zabbix_agentd.conf"

try:
    with open(zabbix_conf_path, 'r') as file:
        lines = file.readlines()

    for i, line in enumerate(lines):
        if "LogFileSize=0" in line:
            lines[i] = "LogFileSize=10\n"
        elif "# DebugLevel=3" in line:
            lines[i] = "DebugLevel=3\n"
        elif line.startswith("Server=127.0.0.1"):
            lines[i] = "Server=10.64.2.3\n"
        elif "# ListenPort=10050" in line:
            lines[i] = "ListenPort=10050\n"
        elif "# StartAgents=3" in line:
            lines[i] = "StartAgents=5\n"
        elif "# Hostname=" in line:
            lines[i] = f"Hostname={ip_lan}\n"
        elif "# Timeout=3" in line:
            lines[i] = "Timeout=5\n"

    with open(zabbix_conf_path, 'w') as file:
        file.writelines(lines)

    print(f"Linhas em '{zabbix_conf_path}' substituídas com sucesso.")
except IOError as e:
    print(f"Erro ao substituir linhas em '{zabbix_conf_path}': {e}")
# Reiniciar o Zabbix

comando_restart_zabbix = "service zabbix-agent restart"

# Execute o comando para reiniciar o Zabbix
try:
    subprocess.run(comando_restart_zabbix, shell=True, check=True)
    print("Zabbix reiniciado com sucesso.")
except subprocess.CalledProcessError as e:
    print(f"Erro ao reiniciar o Zabbix: {e}")