import os
import shutil
import subprocess

caminho_arquivo_rede = "/etc/network/interfaces"
saida = subprocess.check_output(['ip', 'a'])

configuracoes = {
    caminho_arquivo_rede: "interfaces de rede",
}

def exibir_menu():
    arte_ascii = """
    CONFIGURACOES INICIAIS DO PROXMOX                
    Selecione uma opção
    1 - Configuração completa
    2 - Configurações gerais, sem configurar a rede
    3 - Configurar apenas Rede                                  
    4 - Validação de rede
"""

    print(arte_ascii)

def conf_rede():
    script_dir = os.path.dirname(os.path.abspath(__file__))

    caminho_arquivo_rede = os.path.join(script_dir, "interfaces.txt")
    caminho_arquivo_ntp = os.path.join(script_dir, "ntp.txt")
    caminho_arquivo_hosts = os.path.join(script_dir, "hosts.txt")


    def ler_arquivo(caminho_completo):
        with open(caminho_completo, 'r') as arquivo:
            return arquivo.read()

    interface1 = input("Digite o nome da primeira interface: ")
    interface2 = input("Digite o nome da segunda interface: ")
    vlan_wan = input("Digite o número vlan WAN: ")
    ip_wan = input("Qual é o ip WAN (Ex: 189.113.7.4): ")
    mask_wan = input("Qual é a máscara WAN (Ex: 29): ")
    gw_wan = input("Qual é o gw WAN (Ex: 189.113.7.1): ")
    vlan_lan = input("Digite o número vlan LAN: ")
    ip_lan = input("Qual é o ip LAN (Ex: 10.32.0.2): ")
    mask_lan = input("Qual é a máscara LAN (Ex: 28): ")
    gw_lan = input("Qual é o gw LAN (Ex: 10.32.0.1): ")
    contrato = input("Qual é o contrato: ")

    conteudo_rede = ler_arquivo(caminho_arquivo_rede)
    conteudo_ntp = ler_arquivo(caminho_arquivo_ntp)
    conteudo_hosts = ler_arquivo(caminho_arquivo_hosts)

    # Substituir as variáveis nos textos
    conteudo_rede = conteudo_rede.format(interface1=interface1, interface2=interface2,
                                         vlan_wan=vlan_wan, ip_wan=ip_wan, mask_wan=mask_wan,
                                         gw_wan=gw_wan, vlan_lan=vlan_lan, ip_lan=ip_lan,
                                         mask_lan=mask_lan, gw_lan=gw_lan, contrato=contrato)
    conteudo_hosts = conteudo_hosts.format(ip_lan=ip_lan, contrato=contrato)

    # Escrever o conteúdo nos arquivos de configuração
    try:
        with open(caminho_arquivo_rede, 'w') as arquivo:
            arquivo.write(conteudo_rede)
        print(f"Arquivo '{caminho_arquivo_rede}' criado com sucesso.")
    except IOError as e:
        print(f"Erro ao criar o arquivo '{caminho_arquivo_rede}': {e}")

    try:
        with open(caminho_arquivo_ntp, 'w') as arquivo:
            arquivo.write(conteudo_ntp)
        print(f"Arquivo '{caminho_arquivo_ntp}' criado com sucesso.")
    except IOError as e:
        print(f"Erro ao criar o arquivo '{caminho_arquivo_ntp}': {e}")

    try:
        with open(caminho_arquivo_hosts, 'w') as arquivo:
            arquivo.write(conteudo_hosts)
        print(f"Arquivo '{caminho_arquivo_hosts}' criado com sucesso.")
    except IOError as e:
        print(f"Erro ao criar o arquivo '{caminho_arquivo_hosts}': {e}")


    # Verificar se os arquivos foram criados e exibir informações relevantes
    def verificar_arquivos():
        arquivos = {
            caminho_arquivo_rede: "Arquivo de configuração da rede",
            caminho_arquivo_ntp: "Arquivo de configuração do NTP",
            caminho_arquivo_hosts: "Arquivo de configuração do hosts"
        }
        for caminho, descricao in arquivos.items():
            if os.path.exists(caminho):
                print(f"{descricao} criado com sucesso:")
                with open(caminho, 'r') as arquivo:
                    print(arquivo.read())
                print()
            else:
                print(f"Erro: {descricao} não foi criado.")

    try:
        with open(caminho_arquivo_rede, 'w') as arquivo:
            arquivo.write(conteudo_rede)
        print(f"Arquivo '{caminho_arquivo_rede}' criado com sucesso.")
    except IOError as e:
        print(f"Erro ao criar o arquivo '{caminho_arquivo_rede}': {e}")
    try:
        shutil.copy(caminho_arquivo_rede, "/etc/network/interfaces")
        print(f"Arquivo '{caminho_arquivo_rede}' movido para /etc/network/interfaces.")
    except Exception as e:
        print(f"Erro ao mover o arquivo '{caminho_arquivo_rede}': {e}")
    try:
        shutil.copy(caminho_arquivo_ntp, "/etc/chrony/chrony.conf")
        print(f"Arquivo '{caminho_arquivo_ntp}' movido para /etc/chrony/chrony.conf.")
    except Exception as e:
        print(f"Erro ao mover o arquivo '{caminho_arquivo_ntp}': {e}")
    try:
        shutil.copy(caminho_arquivo_hosts, "/etc/hosts")
        print(f"Arquivo '{caminho_arquivo_hosts}' movido para /etc/hosts.")
    except Exception as e:
        print(f"Erro ao mover o arquivo '{caminho_arquivo_hosts}': {e}")
    
    verificar_arquivos()


exibir_menu()

def selecionar_opcao():
    while True:
        opcao = input("Digite o número da opção desejada: ")
        if opcao.isdigit() and 1 <= int(opcao) <= 4:
            opcao = int(opcao)
            if opcao == 1:
                conf_rede()
            elif opcao == 2:
                pass
            elif opcao == 3:
                conf_rede()
            elif opcao == 4:
                apresentar_dados(configuracoes)
            break
        else:
            print("Opção inválida. Por favor, digite um número de 1 a 4.")
            exibir_menu()

def apresentar_dados(configuracoes):
    for arquivo, descricao in configuracoes.items():
        print(f"\nConfigurações de {descricao}:")
        try:
            with open(arquivo, 'r') as f:
                print(f.read())
        except FileNotFoundError:
            print(f"Arquivo {arquivo} não encontrado.")
        except Exception as e:
            print(f"Erro ao ler o arquivo {arquivo}: {e}")

opcao_selecionada = selecionar_opcao()